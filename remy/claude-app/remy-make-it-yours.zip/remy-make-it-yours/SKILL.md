---
name: remy-make-it-yours
description: "Replace Remy's sample designer with the owner: name, logo, location, clock, contact details, social links, portrait, About, blog byline, search titles and site settings."
---

Replace the sample designer, Remy Varga, with the owner everywhere except the Work and Blog collections, whose sample entries are replaced with remy-add-case-study and remy-add-blog-post.

## Working from outside Framer

- Read remy-base first: it has the Framer MCP setup and the rules for every Remy task. If you can't reach the project, ask the owner to connect Framer and share the project link.
- Names in this skill are exact names in the project. Find each by name; if one is missing, ask, and never build a replacement.
- Framer MCP edits the owner's main version directly unless you work on a branch (if the owner's plan has them); if you use one, give the owner its name and link. Never publish, and merge only when the owner asks.
- Images come from the owner, as public links or dropped into their fields in Framer. Never generate or download images unless asked.
- If your tools can't do a step, give the owner the exact steps and list them in your report.
- Check your work at the widths and modes remy-base lists, and follow its Before you report steps. If you can't see something, say so in your report.

## 1. Ask in one message

One numbered list, each item with a short example; say anything they don't have yet can stay a placeholder:

1. Full name, for the footer, page titles, alt text and About (Remy Varga)
2. Logo text, usually the first name; the Accent full stop is added (Remy)
3. City, time zone, and a 12-hour or 24-hour clock (San Jose, Pacific time, 12-hour)
4. Email
5. Links for the networks they use: Instagram, LinkedIn, Dribbble, X
6. A one-line role, and the kinds of work they take on (Independent Product and Brand Designer; product, brand and systems work)
7. A portrait photo, at least 1200 px wide, and a short caption (Remy, at work)
8. When they're next free for new work (Booking from [month and year])
9. For About: a two- or three-sentence intro, their background, their approach, and their career as years and roles (2019–2023, Senior product designer, Pliant)
10. One or two sentences for the byline under every blog post (I'm Remy, a designer working across product, brand and systems.)
11. /design-system is their private reference for the site's styles: keep it published but hidden from search, or make it a draft page so it isn't on the live site at all?

Wait for answers. Anything missing becomes a placeholder in capitals and square brackets, such as [YOUR EMAIL]. A link can't hold a placeholder: leave it as it is and list it.

## 2. Change

1. Wordmark: the logo text. Keep the Accent full stop.
2. Footer: the copyright line, © with the current year and the full name.
3. Nav: the city in the bar and in the phone menu ("Based in [City] ·", followed by the clock); the Local Time clock's Time Zone (an IANA name such as America/Vancouver) and Clock (12-hour or 24-hour); the phone menu's email (text and mailto link). Remove the Design system link from the bar and the phone menu.
4. Main layout: delete the floating Use template button (the Use template (floating) layer, which links to a placeholder remix link) on Desktop, Tablet and Phone.
5. Contact CTA: the email (text and mailto link) and each social link's address.
6. Contact Form: "Dear Remy," becomes the owner's first name. Send To, where messages go, often looks saved through the connector when it isn't, and a form that sends nowhere loses the owner real enquiries. So give the owner the steps every time: select the Contact Form, select Form, add their email under Send To, then confirm it from the email Framer sends. Report it as set only if a new session reads it back with their address.
7. /contact: the intro's kinds of work ("across [kinds of work]") and the page's search description, or [THE KINDS OF WORK YOU TAKE ON]; the Detail rows Name, Email (value and mailto link), Based in, Availability and Elsewhere (each network's link), and both Polaroids' image, caption and alt text (one shows only on phones).
8. Home: the role line under the statement (the Subheading layer in Hero text, inside Hero and Work); change its words only, since the stack code finds it by name and times the prints from its fade. Write the role in Title Case, whatever case the owner typed it in ("[Full name], Independent Product Designer"), here and in the site title. Then, in About, the Polaroid's image, caption and alt text, the intro, and the Background, Approach and Career rows (years and roles, and the city on the current role).
9. /blog/:slug: in the Written by byline, the Polaroid's image and alt text, and the bio.
10. Portraits: with the owner's photo, put it in every Polaroid above with their caption and the alt text "Portrait of [Full name]". Without one, keep the sample photo but don't put the owner's name on someone else's face, which misleads visitors and screen reader users: set each caption and alt text to [YOUR PORTRAIT], and keep the caption they gave for the report. Change only the Polaroids and Details in steps 7 to 9. The samples on /design-system and in the User guide design page use the same components but document the template, so leave them as they are.
11. Search titles: replace "Remy Varga" with the full name on /work, /blog, /contact and /404, and in the case study and blog post title patterns ("{{Title}} – [Full name]").
12. Site settings: site title ("[Full name] – [Role]", with the role as worded in the role line from step 8) and description (one sentence from their About intro, under about 155 characters), plus their own favicon and 1200 × 630 social image if they have them; the template's are Remy's.
13. Networks without a profile link: turn off the visibility of every network the owner didn't give a link for, whether they don't use it or just didn't say, in the Contact CTA and the Elsewhere row. A visible icon that opens a network's home page looks broken. Don't delete them, so they can come back, and list each hidden one with the link it still holds.
14. /design-system: keep it, hidden from search or as a draft page, as the owner chose. It's the owner's private reference, the other Remy skills read it, and the User guide design page links to it, so never delete it, even if the owner asks; explain why in a line and offer a draft page instead. A draft page stays in the project but isn't published; if your tools can't make one, give the owner the steps. Change nothing else on it: its samples are the template's documentation.

For anything your tools can't reach, give the owner the text and the steps.

## Rules

- Use only what the owner tells you, never their Framer account's name or time zone; never invent facts, years or employers.
- Leave the Home hero statement and the services as they are; offer remy-design-system if the owner wants them rewritten.
- Place the owner's words exactly as given. Don't add emphasis such as italics that they didn't ask for; suggest it instead.
- Write anything new in the voice from section 07 of /design-system, and reread it as remy-remove-ai-writing describes.

## Check before you report

Follow Before you report in remy-base after every turn that changes something, follow-ups included. For this skill:

1. Take canvas screenshots of Home, /contact and a blog post at Desktop and Phone, in light and dark.
2. Before the owner publishes, ask them to make one small real edit in the editor to the Main layout and to the search titles of /work, /blog, /contact and /404 (change any value, then change it back). After they publish, ask them to check the browser tab titles on those pages, and that no Use template button shows.

## Done when

- Searching the pages, components, layout templates, alt text, page titles and descriptions finds no "Remy", "Varga", "San Jose" or hello@remyvarga.com, and no "Pacific time" unless the owner is on Pacific time. /design-system and the User guide design page are the template's own and may keep the name Remy.
- The logo, the Nav and the role line fit at every size, 360 px included. A logo text longer than about 14 characters often runs off the edge on small phones: check it at 360 px, and if you can't view that width, suggest the first name and ask the owner to check Preview at the smallest phone size. Don't say it fits unless you saw it.
- No Design system link in the Nav, and no Use template button on any page, in the read-back and in the screenshots.
- The email links open the owner's address, and every visible social link opens their profile.

## Report

What you changed, page by page and component by component; anything that didn't stick, with the steps to do it by hand; every placeholder left, including the portrait and the caption to use with it; every link still pointing at a network's home page, hidden ones included; and what the owner still has to do: Send To, unless a new session read it back with their address; site settings your tools couldn't reach; the sample case studies and posts to replace.
